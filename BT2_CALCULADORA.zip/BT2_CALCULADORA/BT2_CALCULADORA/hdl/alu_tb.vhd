library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_signed.all;
use ieee.std_logic_arith.all;

entity alu_tb is
-- Entidad vac�a para testbench
end entity;

architecture sim of alu_tb is

    -- Se�ales de conexi�n
    signal op1_i     : std_logic_vector(10 downto 0) := (others => '0');
    signal op1_sgn   : std_logic := '0';
    signal op2_i     : std_logic_vector(10 downto 0) := (others => '0');
    signal op2_sgn   : std_logic := '0';
    signal operacion : std_logic_vector(1 downto 0) := "11"; -- Empezamos en reposo
    signal res_o     : std_logic_vector(20 downto 0);
    signal inicio    : std_logic;

begin

    -- Instancia de la ALU
    uut: entity work.alu
        port map (
            op1_i     => op1_i,
           -- op1_sgn   => op1_sgn,
            op2_i     => op2_i,
            --op2_sgn   => op2_sgn,
            operacion => operacion,
            res_o     => res_o,
            inicio    => inicio
        );

    process
    begin
        -- ==========================================================
        -- CASO 1: SUMA L�MITE POSITIVA (999 + 999 = 1998)
        -- ==========================================================
        op1_i <= conv_std_logic_vector(999, 11);
        op2_i <= conv_std_logic_vector(999, 11);
        operacion <= "00";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 2: SUMA L�MITE NEGATIVA (-999 + -999 = -1998)
        -- Comprueba que la extensi�n de signo manual funciona en sumas
        -- ==========================================================
        op1_i <= conv_std_logic_vector(-999, 11);
        op2_i <= conv_std_logic_vector(-999, 11);
        operacion <= "00";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 3: RESTA QUE CAMBIA DE SIGNO (10 - 20 = -10)
        -- ==========================================================
        op1_i <= conv_std_logic_vector(10, 11);
        op2_i <= conv_std_logic_vector(20, 11);
        operacion <= "01";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 4: MULTIPLICACI�N M�XIMA POSITIVA (999 * 999 = 998001)
        -- CR�TICO: Aqu� verificar�s que res_o es POSITIVO gracias a los 21 bits
        -- ==========================================================
        op1_i <= conv_std_logic_vector(999, 11);
        op2_i <= conv_std_logic_vector(999, 11);
        operacion <= "10";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 5: MULTIPLICACI�N M�XIMA NEGATIVA (999 * -999 = -998001)
        -- ==========================================================
        op1_i <= conv_std_logic_vector(999, 11);
        op2_i <= conv_std_logic_vector(-999, 11);
        operacion <= "10";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 6: MULTIPLICACI�N DE NEGATIVOS (-999 * -999 = 998001)
        -- ==========================================================
        op1_i <= conv_std_logic_vector(-999, 11);
        op2_i <= conv_std_logic_vector(-999, 11);
        operacion <= "10";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 7: VALORES CERO (Cualquier num * 0 = 0)
        -- ==========================================================
        op1_i <= conv_std_logic_vector(555, 11);
        op2_i <= conv_std_logic_vector(0, 11);
        operacion <= "10";
        wait for 20 ns;

        -- ==========================================================
        -- CASO 8: REPOSO / OPERACI�N NO V�LIDA
        -- Comprueba que 'inicio' se pone a 0 y 'res_o' a 0
        -- ==========================================================
        operacion <= "11";
        wait for 20 ns;

        wait; 
    end process;

end sim;